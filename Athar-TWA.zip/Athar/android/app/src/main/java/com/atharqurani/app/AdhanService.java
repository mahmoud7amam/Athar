package com.atharqurani.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.content.res.AssetFileDescriptor;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.graphics.PixelFormat;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.View;
import android.view.WindowManager;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** خدمة أمامية: تشغّل الأذان من ملف داخل التطبيق (بدون نت) وتعرض إشعار + شاشة الأذان. */
public class AdhanService extends Service {
    static final String CHANNEL = "athar_adhan";
    static final String ACTION_ENDED = "com.atharqurani.app.ADHAN_ENDED";
    static final int NOTIF_ID = 4101;

    private MediaPlayer mp;
    private PowerManager.WakeLock wl;
    private final Handler h = new Handler(Looper.getMainLooper());
    private AudioManager am;

    /** تشغيل الأذان لصلاة رقم idx (0..4) بدون قفل */
    static void begin(Context c, int idx, long epoch) { begin(c, idx, epoch, false); }

    /** lock = true: يعرض تذكيرًا اختياريًا بعد الأذان مع إمكانية إغلاقه أو تأجيله. */
    static void begin(Context c, int idx, long epoch, boolean lock) { begin(c, idx, epoch, lock, true); }

    static void begin(Context c, int idx, long epoch, boolean lock, boolean sound) {
        // احفظ سياق التذكير قبل بدء الخدمة؛ لو النظام منع تشغيل الخدمة وظلّ الإشعار هو البديل، تظل بطاقة التأكيد مرتبطة بالصلاة الصحيحة.
        if (lock && AdhanPrefs.lockOn(c)) AdhanPrefs.setLockPending(c, idx, epoch);
        Intent s = new Intent(c, AdhanService.class).putExtra("idx", idx).putExtra("epoch", epoch)
                .putExtra("lock", lock).putExtra("silent", !sound);
        try {
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(s); else c.startService(s);
        } catch (Exception e) {
            try { ((NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE)).notify(NOTIF_ID, build(c, idx, epoch, sound, !sound)); } catch (Exception ignored) { }
        }
    }

    /** تذكير الصلاة يعمل حتى عند إيقاف صوت الأذان؛ لا يشغّل أي صوت. */
    static void beginReminder(Context c, int idx, long epoch) { begin(c, idx, epoch, true, false); }

    private static void ensureChannel(Context c) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm.getNotificationChannel(CHANNEL) != null) return;
        NotificationChannel ch = new NotificationChannel(CHANNEL, "الأذان ومواقيت الصلاة", NotificationManager.IMPORTANCE_HIGH);
        ch.setDescription("تنبيه دخول وقت الصلاة وصوت الأذان");
        ch.setSound(null, null);
        ch.enableVibration(true);
        ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(ch);
    }

    static Notification build(Context c, int idx, long epoch, boolean withSound) {
        return build(c, idx, epoch, withSound, false);
    }

    static Notification build(Context c, int idx, long epoch, boolean withSound, boolean silent) {
        ensureChannel(c);
        String name = AdhanScheduler.NAMES[Math.max(0, Math.min(4, idx))];
        String city = AdhanPrefs.city(c);
        int pf = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        Intent ui = new Intent(c, AdhanActivity.class).putExtra("idx", idx).putExtra("epoch", epoch).putExtra("silent", silent)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent uiPi = PendingIntent.getActivity(c, 7100 + idx, ui, pf);
        PendingIntent stopPi = PendingIntent.getBroadcast(c, 7200, new Intent(c, AdhanReceiver.class).setAction(AdhanScheduler.ACTION_STOP), pf);

        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, CHANNEL) : new Notification.Builder(c);
        b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("🕌 صلاة " + name + " الآن")
                .setContentText("حان الآن موعد صلاة " + name + (city.length() > 0 ? " حسب توقيت " + city : ""))
                .setContentIntent(uiPi)
                .setFullScreenIntent(uiPi, true)
                .setCategory(Notification.CATEGORY_ALARM)
                .setOngoing(!withSound)
                .setAutoCancel(withSound)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setWhen(epoch > 0 ? epoch : System.currentTimeMillis())
                .addAction(android.R.drawable.ic_media_pause, "إيقاف الأذان", stopPi);
        if (Build.VERSION.SDK_INT < 26) b.setPriority(Notification.PRIORITY_MAX);
        if (withSound && Build.VERSION.SDK_INT < 26) b.setDefaults(Notification.DEFAULT_ALL);
        return b.build();
    }

    @Override
    public int onStartCommand(Intent in, int flags, int startId) {
        int idx = in == null ? 1 : in.getIntExtra("idx", 1);
        long epoch = in == null ? 0 : in.getLongExtra("epoch", 0);
        boolean silent = in != null && in.getBooleanExtra("silent", false);
        if (in != null && in.getBooleanExtra("lock", false) && AdhanPrefs.lockOn(this)) AdhanPrefs.setLockPending(this, idx, epoch);
        Notification n = build(this, idx, epoch, false, silent);
        if (Build.VERSION.SDK_INT >= 29 && !silent) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        else if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, n);
        else startForeground(NOTIF_ID, n);
        h.removeCallbacksAndMessages(null);
        stopPlayback();
        launchScreen(idx, epoch, silent);
        if (silent) {
            // أرسل إشارة انتهاء قصيرة حتى تنتقل الواجهة مباشرة إلى بطاقة التذكير الصوتي.
            h.postDelayed(new Runnable() { @Override public void run() { stopSelf(); } }, 700L);
        } else {
            play();
            // حد أمان للخدمة في حال تعذر انتهاء ملف الصوت أو توقف المشغل.
            h.postDelayed(new Runnable() { @Override public void run() { stopSelf(); } }, 5 * 60 * 1000L + 30000L);
        }
        return START_NOT_STICKY;
    }

    private View overlay;

    /**
     * فتح شاشة الأذان عبر واجهة الإشعار ذات الشاشة الكاملة أو بعد تفاعل المستخدم مع الإشعار.
     * نحتفظ بدعم نافذة قديمة مؤقتًا للأجهزة التي سبق أن منحت التطبيق إذن العرض فوق التطبيقات؛
     * النسخ الجديدة لا تطلب هذا الإذن ولا تعتمد عليه في الاستخدام المعتاد.
     */
    private void launchScreen(int idx, long epoch, boolean silent) {
        removeOverlay();
        try {
            if (Build.VERSION.SDK_INT >= 23 && Settings.canDrawOverlays(this)) {
                WindowManager wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
                int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
                WindowManager.LayoutParams lp = new WindowManager.LayoutParams(1, 1, type,
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, PixelFormat.TRANSLUCENT);
                View v = new View(this);
                wm.addView(v, lp);
                overlay = v;
            }
        } catch (Exception e) { overlay = null; }
        try {
            startActivity(new Intent(this, AdhanActivity.class).putExtra("idx", idx).putExtra("epoch", epoch).putExtra("silent", silent)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP));
        } catch (Exception ignored) { }
        h.postDelayed(new Runnable() { @Override public void run() { removeOverlay(); } }, 4000L);
    }

    private void removeOverlay() {
        if (overlay == null) return;
        try { ((WindowManager) getSystemService(Context.WINDOW_SERVICE)).removeView(overlay); } catch (Exception ignored) { }
        overlay = null;
    }

    private void play() {
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (pm != null) { wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "athar:adhan"); wl.acquire(6 * 60 * 1000L); }
        } catch (Exception ignored) { }
        try {
            am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            try { // لو صوت المنبّه صفر، نرفعه عشان الأذان يتسمع
                int max = am.getStreamMaxVolume(AudioManager.STREAM_ALARM);
                if (am.getStreamVolume(AudioManager.STREAM_ALARM) < Math.max(1, max / 2)) am.setStreamVolume(AudioManager.STREAM_ALARM, Math.max(1, (int) (max * 0.6)), 0);
            } catch (Exception ignored) { }
            try { am.requestAudioFocus(null, AudioManager.STREAM_ALARM, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT); } catch (Exception ignored) { }   // لو فشل ما يوقفش الأذان
            mp = new MediaPlayer();
            mp.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            AssetFileDescriptor afd = getResources().openRawResourceFd(R.raw.adhan);
            mp.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
            afd.close();
            float v = Math.max(0.05f, Math.min(1f, AdhanPrefs.vol(this) / 100f));
            mp.setVolume(v, v);
            mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() { @Override public void onCompletion(MediaPlayer m) { stopSelf(); } });
            mp.setOnErrorListener(new MediaPlayer.OnErrorListener() { @Override public boolean onError(MediaPlayer m, int w, int e) { stopSelf(); return true; } });
            mp.prepare();
            mp.start();
        } catch (Exception e) {
            stopSelf();
        }
    }

    private void stopPlayback() {
        if (mp != null) { try { mp.stop(); } catch (Exception ignored) { } try { mp.release(); } catch (Exception ignored) { } mp = null; }
    }

    @Override
    public void onDestroy() {
        h.removeCallbacksAndMessages(null);
        removeOverlay();
        stopPlayback();
        try { if (am != null) am.abandonAudioFocus(null); } catch (Exception ignored) { }
        try { if (wl != null && wl.isHeld()) wl.release(); } catch (Exception ignored) { }
        stopForeground(true);
        sendBroadcast(new Intent(ACTION_ENDED).setPackage(getPackageName()));
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent i) { return null; }

    static String clock(long epoch) { return new SimpleDateFormat("h:mm a", new Locale("ar")).format(new Date(epoch)); }
}
