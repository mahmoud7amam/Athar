package com.atharqurani.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;

/**
 * جسر الويب ← الأصلي. الصفحة بتفتح رابط intent://... فيوصل هنا:
 *   athar-adhan://sync?on=1&p=11111&v=90&c=القاهرة&t=مواقيت   → حفظ + ضبط المنبّهات
 *   athar-adhan://test?i=1                                    → تجربة الأذان فوراً
 *   athar-adhan://locktest?i=1                                → تجربة تذكير الصلاة (لو مفعّل)
 *   athar-adhan://stop                                        → إيقاف الأذان
 *   athar-adhan://perms                                       → إعادة طلب الأذونات الضرورية للأذان
 * مفيش واجهة: بيخلّص ويرجّع التطبيق فوراً، وبيطلب الأذونات اللازمة مرة واحدة عند تفعيل خصائصها.
 */
public class SyncActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Uri u = getIntent() == null ? null : getIntent().getData();
        if (u == null) { finish(); return; }
        String host = String.valueOf(u.getHost());
        if (!("sync".equals(host) || "locktest".equals(host) || "test".equals(host)
                || "stop".equals(host) || "perms".equals(host))) {
            finish();
            return;
        }
        try {
            if ("sync".equals(host)) {
                String p = u.getQueryParameter("p");
                if (p == null || p.length() < 5) p = "11111";
                int v = 90;
                try { v = Integer.parseInt(u.getQueryParameter("v")); } catch (Exception ignored) { }
                AdhanPrefs.save(this, !"0".equals(u.getQueryParameter("on")), p, v, nz(u.getQueryParameter("c")), u.getQueryParameter("t"));
                String lkp = u.getQueryParameter("lk");     // تذكير الصلاة الاختياري (لو الصفحة بعتته)
                if (lkp != null) {
                    boolean lk = "1".equals(lkp);
                    AdhanPrefs.setLockOn(this, lk);
                    if (!lk) {
                        AdhanPrefs.clearLock(this);
                        AdhanScheduler.cancelLockReminder(this);
                    }
                }
                AdhanScheduler.schedule(this);
            } else if ("locktest".equals(host)) {
                int i = 1;
                try { i = Integer.parseInt(u.getQueryParameter("i")); } catch (Exception ignored) { }
                AdhanService.begin(this, i, System.currentTimeMillis(), AdhanPrefs.lockOn(this));
            } else if ("test".equals(host)) {
                int i = 1;
                try { i = Integer.parseInt(u.getQueryParameter("i")); } catch (Exception ignored) { }
                AdhanService.begin(this, i, System.currentTimeMillis());
            } else if ("stop".equals(host)) {
                stopService(new Intent(this, AdhanService.class));
            } else if ("perms".equals(host)) {
                AdhanPrefs.resetAsked(this);      // المستخدم ضغط «ضبط الأذونات»: نسأل من الأول
            }
        } catch (Exception ignored) { }
        askPermissions();
    }

    private static String nz(String s) { return s == null ? "" : s; }

    /**
     * الأذونات بالترتيب: إشعارات ← ميكروفون عند تفعيل التأكيد الصوتي ← المنبهات الدقيقة ← الشاشة الكاملة (أندرويد 14+).
     */
    private int step = 0;
    private static final int RC_NOTIF = 11, RC_SETTINGS = 12, RC_MIC = 13;

    private void askPermissions() { step = 0; next(); }

    private void next() {
        while (step < 4) {
            int s = step++;
            if (tryStep(s)) return;       // فتح شاشة طلب → هنكمّل في onActivityResult / onRequestPermissionsResult
        }
        if (AdhanPrefs.on(this) || AdhanPrefs.lockOn(this)) AdhanScheduler.schedule(this);
        finish();
        overridePendingTransition(0, 0);
    }

    /** true = فتحنا شاشة لازم نستناها */
    private boolean tryStep(int s) {
        try {
            if (s == 0) {
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                        && !AdhanPrefs.asked(this, "notif")) {
                    AdhanPrefs.setAsked(this, "notif");
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, RC_NOTIF);
                    return true;
                }
            } else if (s == 1) {
                // نطلب الميكروفون وقت تفعيل المستخدم لتأكيد الصلاة، وليس عند أول تشغيل التطبيق.
                if (AdhanPrefs.lockOn(this) && Build.VERSION.SDK_INT >= 23
                        && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED
                        && !AdhanPrefs.asked(this, "mic")) {
                    AdhanPrefs.setAsked(this, "mic");
                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, RC_MIC);
                    return true;
                }
            } else if (s == 2) {
                if (Build.VERSION.SDK_INT >= 31 && (AdhanPrefs.on(this) || AdhanPrefs.lockOn(this)) && !AdhanPrefs.asked(this, "exact")) {
                    AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                    if (am != null && !am.canScheduleExactAlarms()) {
                        AdhanPrefs.setAsked(this, "exact");
                        startActivityForResult(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                                Uri.parse("package:" + getPackageName())), RC_SETTINGS);
                        return true;
                    }
                }
            } else if (s == 3) {
                if (Build.VERSION.SDK_INT >= 34 && (AdhanPrefs.on(this) || AdhanPrefs.lockOn(this)) && !AdhanPrefs.asked(this, "fsi")) {
                    NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                    if (nm != null && !nm.canUseFullScreenIntent()) {
                        AdhanPrefs.setAsked(this, "fsi");
                        startActivityForResult(new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                                Uri.parse("package:" + getPackageName())), RC_SETTINGS);
                        return true;
                    }
                }
            }
        } catch (Exception ignored) { }
        return false;
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code == RC_MIC && (res.length == 0 || res[0] != PackageManager.PERMISSION_GRANTED)) {
            android.widget.Toast.makeText(this, "تأكيد الصلاة الصوتي يحتاج إذن الميكروفون. يمكنك السماح به من إعدادات التطبيق.", android.widget.Toast.LENGTH_LONG).show();
        }
        next();
    }

    @Override
    protected void onActivityResult(int code, int result, Intent data) { next(); }
}
