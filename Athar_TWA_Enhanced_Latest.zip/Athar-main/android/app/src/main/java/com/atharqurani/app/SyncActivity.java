package com.atharqurani.app;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;

/**
 * جسر الويب ← الأصلي. الصفحة بتفتح رابط intent://... فيوصل هنا:
 *   athar-adhan://sync?on=1&p=11111&v=90&c=القاهرة&t=مواقيت   → حفظ + ضبط المنبّهات
 *   athar-adhan://test?i=1                                    → تجربة الأذان فوراً
 *   athar-adhan://locktest?i=1                                → تجربة تذكير الصلاة (لو مفعّل)
 *   athar-adhan://stop                                        → إيقاف الأذان
 *   athar-adhan://perms                                       → إعادة طلب الأذونات الضرورية للأذان
 * مفيش واجهة: بيخلّص ويرجّع التطبيق فوراً، وبيطلب الأذونات اللازمة مرة واحدة عند تفعيل خصائصها.
 */
public class SyncActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Uri u = getIntent() == null ? null : getIntent().getData();
        if (u == null) { finish(); return; }
        String host = String.valueOf(u.getHost());
        try {
            if ("sync".equals(host)) {
                String p = u.getQueryParameter("p");
                if (p == null || p.length() < 5) p = "11111";
                int v = 90;
                try { v = Integer.parseInt(u.getQueryParameter("v")); } catch (Exception ignored) { }
                AdhanPrefs.save(this, !"0".equals(u.getQueryParameter("on")), p, v, nz(u.getQueryParameter("c")), u.getQueryParameter("t"));
                String lkp = u.getQueryParameter("lk");     // تذكير الصلاة الاختياري (لو الصفحة بعتته)
                if (lkp != null) {
                    boolean lk = "1".equals(lkp);
                    AdhanPrefs.setLockOn(this, lk);
                    if (!lk) {
                        AdhanPrefs.clearLock(this);
                        AdhanScheduler.cancelLockReminder(this);
                    }
                }
                AdhanScheduler.schedule(this);
            } else if ("locktest".equals(host)) {
                int i = 1;
                try { i = Integer.parseInt(u.getQueryParameter("i")); } catch (Exception ignored) { }
                AdhanService.begin(this, i, System.currentTimeMillis(), AdhanPrefs.lockOn(this));
            } else if ("test".equals(host)) {
                int i = 1;
                try { i = Integer.parseInt(u.getQueryParameter("i")); } catch (Exception ignored) { }
                AdhanService.begin(this, i, System.currentTimeMillis());
            } else if ("stop".equals(host)) {
                stopService(new Intent(this, AdhanService.class));
            } else if ("perms".equals(host)) {
                AdhanPrefs.resetAsked(this);      // المستخدم ضغط «ضبط الأذونات»: نسأل من الأول
            }
        } catch (Exception ignored) { }
        askPermissions();
    }

    private static String nz(String s) { return s == null ? "" : s; }

    /**
     * الأذونات بالترتيب: إشعارات ← شاشة كاملة (أندرويد 14+) ← استثناء البطارية. إذن الميكروفون لا يُطلب إلا عند اختيار المستخدم التأكيد الصوتي.
     */
    private int step = 0;
    private static final int RC_NOTIF = 11, RC_SETTINGS = 12;

    private void askPermissions() { step = 0; next(); }

    private void next() {
        while (step < 3) {
            int s = step++;
            if (tryStep(s)) return;       // فتح شاشة طلب → هنكمّل في onActivityResult / onRequestPermissionsResult
        }
        finish();
        overridePendingTransition(0, 0);
    }

    /** true = فتحنا شاشة لازم نستناها */
    private boolean tryStep(int s) {
        try {
            if (s == 0) {
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                        && !AdhanPrefs.asked(this, "notif")) {
                    AdhanPrefs.setAsked(this, "notif");
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, RC_NOTIF);
                    return true;
                }
            } else if (s == 1) {
                if (Build.VERSION.SDK_INT >= 34 && !AdhanPrefs.asked(this, "fsi")) {
                    NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                    if (nm != null && !nm.canUseFullScreenIntent()) {
                        AdhanPrefs.setAsked(this, "fsi");
                        startActivityForResult(new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:" + getPackageName())), RC_SETTINGS);
                        return true;
                    }
                }
            } else if (s == 2) {
                // تحسين عمل المنبه في الخلفية اختياري ويظهر مرة واحدة فقط.
                if (Build.VERSION.SDK_INT >= 23 && !AdhanPrefs.asked(this, "batt")) {
                    PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
                    if (pm != null && !pm.isIgnoringBatteryOptimizations(getPackageName())) {
                        AdhanPrefs.setAsked(this, "batt");
                        startActivityForResult(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName())), RC_SETTINGS);
                        return true;
                    }
                }
            }
        } catch (Exception ignored) { }
        return false;
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        next();
    }

    @Override
    protected void onActivityResult(int code, int result, Intent data) { next(); }
}
